PatchGuard IT Website Starter

Files included:
- index.html
- style.css

How to use:
1. Open index.html in your browser to preview.
2. Replace info@patchguardit.com with your real business email.
3. Upload both files to your hosting provider or website builder.
4. Add your final logo image later if you want it in the header.
